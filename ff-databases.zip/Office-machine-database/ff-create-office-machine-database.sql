/* Purpose: To create a database that manage the absences and overtime of employees
from a office machine company.
*/

/* Script Date: January 23, 2021
Developed by: Fabiola Faria
*/

create database OfficeMachine
;

use OfficeMachine
;