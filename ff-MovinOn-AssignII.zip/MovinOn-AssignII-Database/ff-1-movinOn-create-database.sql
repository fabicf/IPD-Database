/* Purpose: To create a database that manages employees, drivers, customers, and orders data. 
*/

/* Script Date: January 31, 2021
Developed by: Fabiola Faria
*/

create database movinOn
;

-- switch to the Flix database
-- Syntax: use database_name;
use movinOn
;

